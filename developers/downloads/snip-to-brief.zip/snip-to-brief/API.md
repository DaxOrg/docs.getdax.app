# Native JavaScript accelerators — API v1

Dax can install user-authored accelerators from a folder containing `manifest.json` and `main.js`. JavaScript describes a native view tree; SwiftUI and AppKit render it. There is no HTML, WebView, Node installation, native plugin loading, or shell execution.

## Install and develop

Open Settings → Accelerators → **Custom Accelerators…**, then **Install from Folder…**. Review the package's author, version and requested access. The accelerator appears in the normal launcher and sidebar; assign its shortcut in its settings pane. New packages do not claim a default shortcut. Community usage statistics stay local.

For a self-contained developer starter, download [snip-to-brief.zip](../Examples/Packages/snip-to-brief.zip), unzip it, and import the enclosed `snip-to-brief` folder. The archive includes commented source, the API guide, SDK types, and a walkthrough. Rebuild it with `Scripts/package-accelerator.sh`.

Start from an example:

- `Examples/Accelerators/format-json`: selected text → native editor → format → copy; completely local.
- `Examples/Accelerators/snip-to-brief`: snip → optional annotation → local OCR or vision AI → copy.
- `Examples/Accelerators/image-studio`: model discovery → reference image → image generation → cutout → save, copy or upload.

Copy an example folder, choose your own reverse-domain ID, edit `main.js`, then import it. Import again to update; installation snapshots the reviewed bytes and replaces the package atomically. There are no install hooks. Only the manifest and main script are installed. Bundle dependencies into `main.js` if using a build tool; TypeScript can compile against `SDK/dax.d.ts`. Node packages needing filesystem, process, browser or network globals cannot run.

**Reload Installed** rediscovers already approved snapshots; it does not approve edits. Changing an installed file makes the package unavailable until it is imported and reviewed again. Shortcuts survive an unavailable package. Removing a package releases its shortcut but retains its local data for reinstalling.

Direct and Setapp builds have separate packages and data under their existing Application Support homes (`Dax` / `Dax-Setapp`). Nothing here uploads your extension code.

## Manifest

```json
{
  "id": "com.example.format-json",
  "name": "Format JSON",
  "version": "1.0.0",
  "apiVersion": 1,
  "entry": "main.js",
  "icon": "curlybraces",
  "author": "Your name",
  "description": "Format selected or pasted JSON.",
  "input": "selectedText",
  "permissions": ["selection.read", "clipboard.write"]
}
```

`id`, `name`, `version`, `apiVersion`, `entry`, `icon` and `permissions` are required. `author`, `description`, `input` and `requiresNetwork` are optional. Icons are SF Symbol names. `app.getdax.*` is reserved. `apiVersion` is exactly 1; unsupported versions fail explicitly. `entry` is exactly `main.js`, UTF-8, at most 1 MB. The manifest is at most 32 KB. Symlinked input files are rejected.

`input: "selectedText"` captures the selection before the palette takes focus and requires `selection.read`. With no selection, `context.input.text` is empty. Omit `input` to skip reading from other applications. `requiresNetwork: true` uses the standard offline launcher gate; omit it for accelerators that also do useful local work.

## State and native UI

Call `dax.defineAccelerator({ activate(context) { ... } })` once. Mount a pure render function with `dax.ui.mount(() => ...)`. Create state using `dax.state(initial)`, read with `.get()`, and change with `.set(value)` or `.set(previous => next)`.

Rendering must not mutate state. Consecutive state updates are batched. Functions assigned to `onPress`, `onChange`, and `onSelect` stay in JavaScript; callback IDs cross XPC. The SDK catches unhandled callback/activation errors and Dax presents a native error screen. Catch expected errors in your own code and display a helpful state instead.

Give **explicit stable IDs to every editable or interactive component**, especially inside conditional or reordered layouts. Otherwise the SDK derives IDs from position. Duplicate IDs fail validation. Each render acknowledges the latest input sequence; Swift ignores stale renders so slow JavaScript cannot overwrite more recent typing. Native multiline editors preserve their identity, selection and undo history; smart quotes, dashes and replacements are disabled.

Components:

| Component | Properties |
|---|---|
| `column`, `form`, `row` | `children` (false/null entries are omitted) |
| `text`, `markdown` | `text`; Markdown supports inline formatting |
| `textField`, `textArea` | `label`, `value`, `placeholder`, `onChange`; optional `height` for textArea |
| `button` | `title`, `onPress`, `disabled` |
| `toggle` | `label`, boolean `value`, `onChange` |
| `picker` | `label`, `value`, `options: [{id,title}]`, `onChange` |
| `list` | `items: [{id,title,subtitle?}]`, optional selected `value`, `onSelect(id)` |
| `code` | `text`, optional `height`; Dax detects the language |
| `image` | image handle in `image`, optional accessible `label` and `height` |
| `progress`, `emptyState` | optional `title`; emptyState also takes `text` |

Each component can have `id` and `disabled`. Layout uses Dax's surface scale, colors and spacing. Authors cannot inject arbitrary Swift classes or styles. API v1 uses a fixed 700×560 palette with scrolling content; heights are clamped to 44–360 points. Trees are limited to 200 nodes and 12 levels, lists to 200 unique items, and individual text fields to 200 KB. Total messages must fit within 1 MB.

Escape returns to the launcher when opened from it; the header always offers Close. Closing, disabling, removing, replacing, reloading, or signing out revokes the invocation. Only one accelerator invocation is active at once. Launching another closes the previous one.

## Capabilities and permissions

All methods below return Promises. Errors reject with a user-readable message. The Swift broker binds requests to the installed manifest; a script cannot select another extension's identity or grants. OS Accessibility/Screen Recording permission is still required where applicable.

| Permission | Methods |
|---|---|
| `selection.read` | launch-time selected text input |
| `clipboard.read` | `clipboard.readText()`, `clipboard.readImage()` |
| `clipboard.write` | `clipboard.writeText(text)`, `clipboard.writeImage(image)` |
| `capture.snip` | `capture.snip()` — always an interactive region selection |
| `images.process` | `images.recognizeText(image)`, `images.removeBackground(image)`, `images.annotate(image)` |
| `ai.text` | `ai.transform({text,instruction})`, `ai.ask({question,...})` |
| `ai.vision` | additionally required for images passed to `ai.ask` |
| `ai.image` | `ai.generateImage({prompt,model,...})` |
| `files.userSelected` | `files.pickImage()`, `files.saveImage(image)` — native user file dialogs |
| `storage.upload` | `upload.image(image)` — returns a public URL |
| No additional grant | `ai.models()`, `images.release(image)`, `storage.get/set`, `ui.toast`, `ui.close` |

Image values are opaque, invocation-scoped handles, not paths or base64. Use them as inputs to image/AI/upload APIs or `ui.image`. Release unused images. At most 16 images / 80 MB total are retained; individual inputs are at most 30 MB and 32 million pixels. Image saves produce PNG. OCR and background removal run locally through Dax's existing Vision implementations. Annotation opens Dax's existing annotation editor.

`ui.toast({title})` always identifies the accelerator. `ui.close()` ends its invocation; do not expect code after that call to run.

`storage.get(key)` / `storage.set(key,value)` store JSON locally, separately per accelerator ID (256 KB total, keys at most 100 bytes). Missing keys return null. This storage is not a secret vault; do not store passwords or API tokens. No access to Dax's Secrets accelerator or account Keychain is exposed.

## AI and uploads

`ai.models()` returns the choices the installed Dax build supports. Text/vision use `model: "default"`: the existing backend owns selection. Arbitrary text model IDs are explicitly rejected. Image models come from `ImageGenModel.allCases`, keeping hidden/unavailable models out of the SDK.

```javascript
const answer = await dax.ai.ask({
  question: "Explain this error and suggest a fix",
  images: [await dax.capture.snip()],
  search: "off"
});
// answer: {text, sources: [{title, url}]}
```

`search` can be `off`, `search`, or `research`. At most four images / 24 MB can be passed to Ask. Questions are at most 32 KB. `ai.transform` accepts text up to 100 KB and an instruction up to 8 KB.

```javascript
const result = await dax.ai.generateImage({
  prompt: "A friendly sheep mascot",
  model: "nanoBanana", // query ai.models() rather than hardcoding in production
  aspectRatio: "1:1",
  background: "transparent",
  images: []
});
// result: {image, model, cost}; model is the server's slug, cost may be null.
```

Generation uses the existing 4096-byte prompt limit and up to ten PNG references, each at most 8 MB. Consult `SDK/dax.d.ts` for aspect ratios. Generated image hosting and billing follow the existing Generate Image client.

Dax asks once per invocation before the first AI request, and separately before uploading to storage. There is at most one online operation in flight and twelve online operations per invocation. These are client bounds, not substitutes for server quota enforcement. AI uses existing `MeteredAPI` clients, with no token exposed to JavaScript. Closing cancels pending client work; it cannot refund an operation already accepted by the service.

`upload.image` goes through `StorageRouter`, respecting the person's verified destination and refusing unconfigured own storage. It never silently falls back to managed storage. Setapp uses its existing managed destination and AI routing. SDK model discovery does not establish that a real Setapp subscription has the required upstream AI scope; that remains a live integration check.

## Runtime and isolation

`DaxExtensionHost.xpc` is signed and embedded in both app builds. It is App Sandboxed, without network, user-files, automation, camera, microphone or app-group entitlements. Its only additional entitlement enables JavaScriptCore JIT. The main app's entitlements are unchanged.

The helper receives source and JSON context, creates a fresh JS virtual machine per connection, and exposes only the SDK message bridge. Normal cancellation releases the VM without exiting the service; repeated process exits would trigger launchd restart throttling. A watchdog terminates the helper if one evaluation blocks for more than two seconds; a process memory watchdog has a 512 MB threshold. After watchdog termination macOS may delay restarting the service briefly. Closing the palette remains available during that delay.

The main app validates all messages, UI trees, permissions, input sizes and image ownership. A pre-main-actor relay bounds message count and bytes so a script cannot flood the UI queue. It caps concurrent capability requests, update rate and invocation duration (30 minutes). There is no arbitrary HTTP, shell execution, background scheduling, remote package fetching, JSX runtime, React reconciler, or arbitrary filesystem access in API v1. Those require their own supported contracts, not bridges to internal objects.

## Verification and manual acceptance

Automated checks:

```sh
Scripts/extension-check.sh
Scripts/hotkey-audit.py .
Scripts/extension-xpc-check.sh /path/to/signed/DaxExtensionHost.xpc
/path/to/signed/Dax.app/Contents/MacOS/Dax --extension-native-check \
  "$PWD/Examples/Accelerators/format-json/main.js" /tmp/dax-extension-ui.png
```

The native check is DEBUG-only and enters before the app delegate: no account initialization, hotkeys, service startup, package installation or backend calls. It checks actual NSTextView identity, focus, undo and JS round trips, then writes a snapshot. The XPC check uses its own temporary signed test app and never launches the user's Dax.

Before shipping, run both signed app variants and manually verify:

1. Import all three examples; review permissions; assign shortcuts; pin/reorder, relaunch, disable/enable and remove.
2. JSON editing: type quickly, select, undo, paste, use IME composition, toggle appearance; Escape and Close return focus correctly.
3. Snip: cancel, annotate, cancel annotation, OCR, vision Ask, copy. Confirm first-use OS permission recovery.
4. Image Studio: discover models, generate/edit with a reference, remove background, save, upload using each configured storage destination.
5. Denied grant, offline state, quota exhaustion and sign-out mid-request; no late clipboard/UI effects.
6. Reimport changed permissions; tamper with installed main.js and reload; restore via import without losing its shortcut.
7. A throwing script and an infinite loop leave a recoverable native error screen; another accelerator launches afterward.
8. Perform real AI calls in direct and Setapp builds, including Setapp vision/generation scope. Automated checks never spend credits or upload files.
