# Snip to Brief — native accelerator starter

A working example of a native Dax accelerator written in JavaScript. Capture a screen region, optionally annotate it, then extract its text locally or ask Dax AI to turn it into a coding brief. Copy the result into your coding agent.

## Install

1. Use a Dax build containing the native accelerator API (macOS 14 or later).
2. If you downloaded the ZIP, unzip it first. Dax imports folders, not ZIP files.
3. Open **Settings → Accelerators → Custom Accelerators… → Install from Folder…**.
4. Select the `snip-to-brief` folder containing `manifest.json` and `main.js`.
5. Review the requested permissions and install. Launch **Snip to Brief** from Dax's launcher. Its settings pane lets you assign a shortcut.

Dax may need macOS Screen Recording permission for a snip. OCR and annotation run locally. **Make brief with Dax AI** sends the chosen image and instruction to Dax AI and uses your account's allowance; Dax asks before the first AI request of each invocation. Nothing is sent automatically when the accelerator opens.

## Package contents

- `manifest.json`: identity, icon, version, and declared capabilities.
- `main.js`: the complete commented source, with no dependencies or build step.
- `README.md`: this guide.
- `API.md`: complete API guide (included in the ZIP).
- `types.d.ts`: TypeScript definitions for editor completion (included in the ZIP).
- `jsconfig.json`: editor configuration (included in the ZIP).

Within the repository, the canonical reference is `Docs/native-accelerators.md` and the definitions are `SDK/dax.d.ts`. Dax installs only the manifest and script; the extra files are for developers.

## Make it yours

1. Copy the folder and change `id` to your own reverse-domain name, for example `com.yourcompany.ui-reviewer`. Do this before installing both versions so your package does not replace the example.
2. Change `name`, `author`, `description` and `icon` in the manifest. Icons use SF Symbol names supported by the user's macOS version.
3. Change the default instruction near the top of `main.js`, or replace the controls and their callbacks. Keep stable IDs on interactive controls.
4. Declare only the permissions your code uses. New capabilities need another import and permission review.
5. Import the folder again after editing. Dax replaces the approved code snapshot; editing an already installed script does not automatically approve that edit.

Useful changes:

- **Bug reporter:** ask for reproduction steps and expected behavior in native text fields, then include those values in `ai.ask()`.
- **Design reviewer:** capture two image handles and send both in the `images` array. Release handles when finished.
- **Offline OCR:** remove the AI button and the `ai.text` / `ai.vision` permissions.
- **Screenshot sharing:** add `storage.upload`, call `dax.upload.image(image.get())`, and copy the returned link. Dax uses the user's configured storage destination.

## How the example works

`dax.state()` stores UI state. `dax.ui.mount()` reruns a pure view-description function after state changes; SwiftUI/AppKit render its output. Callbacks execute in Dax's sandboxed JavaScript helper.

`capture.snip()` returns an opaque image handle. `images.annotate()` returns a new handle. `images.recognizeText()` returns text. `ai.ask()` accepts image handles and returns `{text, sources}`. `clipboard.writeText()` copies the final result.

The `run()` helper prevents overlapping button actions and displays expected errors. `replaceImage()` releases the old image and clears a result that belonged to it. Closing the accelerator cancels pending work and releases the remaining handles; already accepted AI calls may still be billed.

## Rebuild the distributable

From the Dax repository root:

```sh
Scripts/package-accelerator.sh
```

This creates `Examples/Packages/snip-to-brief.zip` from the canonical example, API guide and SDK types. No accelerator code runs during packaging or installation.
