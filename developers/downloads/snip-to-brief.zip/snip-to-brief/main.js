// Native Dax accelerator: no HTML, Node runtime, or framework dependencies.
// See README.md and the bundled types.d.ts for the complete API contract.

const image = dax.state(null);
const answer = dax.state("");
const busy = dax.state(false);
const status = dax.state("");
const instruction = dax.state(
  "Describe this screen as a concise implementation brief, including layout, controls and interactions."
);

// Expected failures (cancelled snips, offline AI, exhausted allowance) stay in
// the interface. An unhandled error would stop the entire invocation.
async function run(action) {
  if (busy.get()) return;
  busy.set(true);
  status.set("");
  try {
    await action();
  } catch (error) {
    status.set(error.message);
  } finally {
    busy.set(false);
  }
}

// Image values are opaque handles. Release images you no longer need; they
// otherwise remain in native memory until this accelerator closes.
async function replaceImage(next) {
  const previous = image.get();
  image.set(next);
  answer.set("");
  if (previous) await dax.images.release(previous);
}

dax.defineAccelerator({
  activate() {
    // This function describes native controls. State changes render a new tree;
    // stable IDs let Dax retain the actual controls, editor focus, and undo.
    dax.ui.mount(() => dax.ui.column({
      id: "brief",
      children: [
        dax.ui.row({
          id: "capture-actions",
          children: [
            dax.ui.button({
              id: "snip",
              title: "Snip screen",
              disabled: busy.get(),
              onPress: () => run(async () => {
                await replaceImage(await dax.capture.snip());
              })
            }),
            dax.ui.button({
              id: "annotate",
              title: "Annotate",
              disabled: busy.get() || !image.get(),
              onPress: () => run(async () => {
                await replaceImage(await dax.images.annotate(image.get()));
              })
            }),
            dax.ui.button({
              id: "ocr",
              title: "Read text locally",
              disabled: busy.get() || !image.get(),
              onPress: () => run(async () => {
                answer.set(await dax.images.recognizeText(image.get()));
              })
            })
          ]
        }),
        image.get() && dax.ui.image({
          id: "capture",
          image: image.get(),
          height: 140,
          label: "Selected screen region"
        }),
        dax.ui.textArea({
          id: "instruction",
          label: "Ask about the image",
          value: instruction.get(),
          onChange: value => instruction.set(value),
          height: 70
        }),
        dax.ui.row({
          id: "answer-actions",
          children: [
            dax.ui.button({
              id: "ask",
              title: "Make brief with Dax AI",
              disabled: busy.get() || !image.get() || !instruction.get().trim(),
              onPress: () => run(async () => {
                // Dax retains account credentials, checks quota, and asks for
                // this invocation's approval before the first online AI call.
                const result = await dax.ai.ask({
                  question: instruction.get(),
                  images: [image.get()]
                });
                answer.set(result.text);
              })
            }),
            dax.ui.button({
              id: "copy",
              title: "Copy result",
              disabled: busy.get() || !answer.get(),
              onPress: () => run(async () => {
                await dax.clipboard.writeText(answer.get());
                await dax.ui.toast({ title: "Result copied" });
              })
            })
          ]
        }),
        status.get() && dax.ui.text({ id: "status", text: status.get() }),
        dax.ui.markdown({ id: "answer", text: answer.get() })
      ]
    }));
  }
});
